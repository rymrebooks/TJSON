#pragma once
#define NEW new (__FILE__,__LINE__)
struct MyHeaders {
	int iCount;
	char *pBuffers;
	MyHeaders() {
		iCount = 0;
		pBuffers = new char[100];
	}

	~MyHeaders() {
		delete pBuffers;
	}
};