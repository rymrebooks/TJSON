#ifndef _Use_SrchNode
#define _Use_SrchNode

void Test_Casting() {
	int iArrayInts[9];

	int iAddrsess1, iAddrsess2;
	int *pInt = &iArrayInts[1]; iArrayInts[1] = 1234321;
	iAddrsess1 = (int)pInt;
	iAddrsess2 = (int)&iArrayInts[2];
	int *pInt2;
	pInt2 = &iArrayInts[3];

	cout << "iAddrsess1: " << iAddrsess1 << " value: " << iArrayInts[1] << " iAddrsess2: " << iAddrsess2;
	int *pInt3;
	long iBackup1 = static_cast<int>(iArrayInts[1]);
	//pInt3 = reinterpret_cast<int*>(iAddrsess1); // &iAddrsess1; same
	pInt3 = (int *)iAddrsess1; // pInt3 = (int *)&iAddrsess1;
	*pInt3 = 987654;
	cout << "\niAddrsess1: " << iAddrsess1 << " value: " << iArrayInts[1] << " iAddrsess2: " << iAddrsess2 << " iBackup1: " << iBackup1;
}

enum NODESTATES : char {
	NSTT_ROOT,
	NSTT_CLONE,
	NSTT_NORMAL,
	NSTT_DUMP,
	NSTT_BRANCH
};


#define VectType long long
#define ItemType int
struct SNode {
	NODESTATES NStt;
	long long ID;
	VectType VctIDCnt, VctIDSz, *VctIDs;
	ItemType ItemCnt, ItemSz, *ItemIDs;
	SNode **SubNodes;
};// in x64, sizeof(SNode): 48

#endif