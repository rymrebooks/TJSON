Target:
	Fast, stablity
	Long time excutation for server side.
	General/flexible purpose in use.
	Only string storage for all type values.
	Float point, number, boolean are used as realm/context.
Author: Trinhdc
Email:  rymrebooks@gmail.com
Donate  @ paypal: rymrebooks@gmail.com 
License: BSD
Version: 1.0.0.0
RoadMap:
	More test to get bugs.
	Listen to users to improve