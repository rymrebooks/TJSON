import os, sys, time, timeit, json

# "C:/canada.json"
def ReadJsonFrom(strfile = "..\\..\\..\\Tools\\_DataSamples\\citm_catalog.json"):
	file = open(strfile, "r") 
	strResult = file.read() 
	print "string json len:", len(strResult)
	return strResult

def LoadAndSee():
	strJson = ReadJsonFrom("..\\..\\..\\Tools\\_DataSamples\\citm_catalog.json")
	strJson2 = ReadJsonFrom("..\\..\\..\\Tools\\_DataSamples\\canada.json")
	elapsed_time, TrueCnt, FailedCnt, Cnt = 0, 0, 0, 100
	for i in range(Cnt):
		start_time = time.time()
		a = json.loads(strJson)
		b = json.loads(strJson2)
		if a == b:
			TrueCnt += 1
		else:
			FailedCnt += 1
		#print i, ", ", 
		elapsed_time += time.time() - start_time

	print "elapsed_time: ", elapsed_time/Cnt, "TrueCnt:", TrueCnt, "FailedCnt:", FailedCnt # elapsed_time:  0.121300005913
	strInput = raw_input("See you ram. Nhap enter to next.")
	
if __name__ == "__main__":
	LoadAndSee()
